package entry.dto;

public class ConvensationDto {
	private Long ownerId;
	private Long owner2Id;
	private Long groupId;
	private Long id;

	public Long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(Long ownerId) {
		this.ownerId = ownerId;
	}

	public Long getOwner2Id() {
		return owner2Id;
	}

	public void setOwner2Id(Long owner2Id) {
		this.owner2Id = owner2Id;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}
}
