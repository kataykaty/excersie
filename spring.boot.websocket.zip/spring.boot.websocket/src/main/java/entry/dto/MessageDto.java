package entry.dto;

public class MessageDto {

	private String messageText;
	private Long senderId;
	private Long id;
	private Long convensationId;
	private String senderName;

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	public Long getSenderId() {
		return senderId;
	}

	public void setSenderId(Long senderId) {
		this.senderId = senderId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public void setConvensationId(Long convensationId) {
		this.convensationId = convensationId;
	}

	public Long getConvensationId() {
		return convensationId;
	}
}
