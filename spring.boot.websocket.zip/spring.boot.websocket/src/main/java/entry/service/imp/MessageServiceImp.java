package entry.service.imp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import entry.dto.ContactDto;
import entry.dto.ConvensationDto;
import entry.dto.GroupDto;
import entry.dto.MessageDto;
import entry.jpaObject.Contact;
import entry.jpaObject.ContactGroup;
import entry.jpaObject.Convensation;
import entry.jpaObject.GroupAndContact;
import entry.jpaObject.Message;
import entry.repository.ContactGroupReposity;
import entry.repository.ContactReposity;
import entry.repository.ConvensationReposity;
import entry.repository.GroupAndContactReposity;
import entry.repository.MessageReposity;
import entry.service.MessageService;

@Service
public class MessageServiceImp implements MessageService {

	private static final String MESSAGE_IS_EMPTY = "Message is empty";

	private static final String CONVENSATION_IS_EMPTY = "Convensation is empty";

	private static final String GROUP_IS_EMPTY = "group is empty";

	@Autowired
	ContactReposity contactReposity;

	@Autowired
	ContactGroupReposity contactGroupReposity;

	@Autowired
	GroupAndContactReposity groupAndContactReposity;

	@Autowired
	ConvensationReposity convensationReposity;

	@Autowired
	private MessageReposity messageReposity;

	@Override
	public List<ContactDto> getListContacts(long userId) {
		Iterable<Contact> contacts = contactReposity.findAll();
		ArrayList<ContactDto> listContactDto = new ArrayList<>();
		ContactDto dto;
		for (Contact contact : contacts) {
			dto = new ContactDto();
			BeanUtils.copyProperties(contact, dto);
			listContactDto.add(dto);
		}
		return listContactDto;
	}

	@Override
	public List<GroupDto> getListGroup(long userId) {
		List<ContactGroup> contacts = groupAndContactReposity.findGroupByContact(userId);
		ArrayList<GroupDto> listGroupDto = new ArrayList<>();
		GroupDto groupDto;
		ContactDto contactDto;
		ArrayList<ContactDto> contactDtos;
		for (ContactGroup groupContact : contacts) {
			groupDto = new GroupDto();
			// TODO beanUtils and fetch data kiem tra.
			BeanUtils.copyProperties(groupContact, groupDto);
			List<Contact> lstContact = groupAndContactReposity.findContactByGroup(groupContact.getId());
			contactDtos = addContactList(lstContact);

			groupDto.setContacts(contactDtos);
			listGroupDto.add(groupDto);
		}
		return listGroupDto;
	}

	@Override
	public Long createContact(ContactDto dto) {
		Contact newContact = new Contact();
		BeanUtils.copyProperties(dto, newContact);
		contactReposity.save(newContact);
		return newContact.getId();
	}

	@Override
	public Long createGroup(GroupDto dto) {
		validateNullPoint(dto, GROUP_IS_EMPTY);
		ContactGroup group = new ContactGroup();
		group.setGroupName(dto.getDisplayName());
		contactGroupReposity.save(group);
		if (!CollectionUtils.isEmpty(dto.getContacts())) {
			List<GroupAndContact> grContacts = new ArrayList<>();
			for (ContactDto contactDto : dto.getContacts()) {
				Contact contact = new Contact();
				contact.setId(contactDto.getId());
				GroupAndContact grContact = new GroupAndContact();
				grContact.setContact(contact);
				grContact.setGroup(group);

				grContacts.add(grContact);
			}
			groupAndContactReposity.save(grContacts);
		}
		return group.getId();
	}

	private void validateNullPoint(Object dto, String message) {
		if (ObjectUtils.isEmpty(dto)) {
			throw new NullPointerException(message);
		}
	}

	@Override
	public Long createConvensation(ConvensationDto dto) {

		validateNullPoint(dto, CONVENSATION_IS_EMPTY);
		Convensation convensation = null;
		if (!ObjectUtils.isEmpty(dto.getGroupId())) {
			convensation = new Convensation();
			ContactGroup group = new ContactGroup();
			group.setId(dto.getGroupId());
			convensation.setGroup(group);
			convensationReposity.save(convensation);

		} else if (!(ObjectUtils.isEmpty(dto.getOwnerId()) || ObjectUtils.isEmpty(dto.getOwner2Id()))) {
			convensation = new Convensation();
			Contact contact = new Contact();
			contact.setId(dto.getOwnerId());

			convensation.setOwnerUser(contact);
			contact = new Contact();
			contact.setId(dto.getOwner2Id());
			convensation.setOwnerUser2(contact);
			convensationReposity.save(convensation);

		}
		return convensation.getId();
	}

	@Override
	public Long getConvensation(ConvensationDto dto) {

		validateNullPoint(dto, CONVENSATION_IS_EMPTY);

		Convensation convensation = null;
		if (!ObjectUtils.isEmpty(dto.getGroupId())) {
			convensation = convensationReposity.findByGroupId(dto.getGroupId());
		} else if (!(ObjectUtils.isEmpty(dto.getOwnerId()) || ObjectUtils.isEmpty(dto.getOwner2Id()))) {
			convensation = convensationReposity.findByContacts(dto.getOwnerId(), dto.getOwner2Id());
		}
		return convensation.getId();
	}

	@Override
	public void deleteMessage(Long messageId) {
		messageReposity.delete(messageId);
	}

	@Override
	public void deleteGroup(Long groupId) {
		contactGroupReposity.delete(groupId);
	}

	@Override
	public GroupDto addMemberIntoGroup(long userId, long groupId) {
		ContactGroup group = new ContactGroup();
		group.setId(groupId);
		Contact contact = new Contact();
		contact.setId(userId);

		GroupAndContact grContact = new GroupAndContact();
		grContact.setGroup(group);
		grContact.setContact(contact);
		groupAndContactReposity.save(grContact);
		return findGroup(groupId);
	}

	@Override
	public GroupDto removeMemberIntoGroup(long userId, long groupId) {
		List<GroupAndContact> grContacts = groupAndContactReposity.findByGroupAndContact(groupId, userId);
		groupAndContactReposity.delete(grContacts);
		return findGroup(groupId);
	}

	@Override
	public GroupDto findGroup(long groupId) {

		ContactGroup contactGroup = contactGroupReposity.findOne(groupId);
		GroupDto groupDto = new GroupDto();
		BeanUtils.copyProperties(contactGroup, groupDto);
		List<Contact> lstContact = groupAndContactReposity.findContactByGroup(contactGroup.getId());
		groupDto.setContacts(addContactList(lstContact));
		return groupDto;
	}

	private ArrayList<ContactDto> addContactList(List<Contact> lstContact) {
		ContactDto contactDto;
		ArrayList<ContactDto> contactDtos;
		contactDtos = new ArrayList<>();
		for (Contact contact : lstContact) {
			contactDto = new ContactDto();
			BeanUtils.copyProperties(contact, contactDto);
			contactDtos.add(contactDto);
		}
		return contactDtos;
	}

	@Override
	public List<MessageDto> getMessageFromConvensation(Long conventionId, int pageIndex, int size) {
		Page<Message> messages = messageReposity.getMessageFromConvention(conventionId,
				new PageRequest(pageIndex, size));
		if (messages != null && messages.hasContent()) {
			List<MessageDto> dtos = new ArrayList<>();
			MessageDto dto;
			for (Message mes : messages) {
				dto = new MessageDto();
				BeanUtils.copyProperties(mes, dto);
				dto.setSenderId(mes.getSender().getId());
				dto.setConvensationId(conventionId);
				dto.setSenderName(mes.getSender().getDisplayName());
				dtos.add(dto);

			}
			return dtos;
		}
		return null;
	}

	@Override
	public Long createMessage(MessageDto dto) {
		validateNullPoint(dto, MESSAGE_IS_EMPTY);
		Message message = new Message();
		message.setMessageText(dto.getMessageText());
		Convensation convensation = new Convensation();
		convensation.setId(dto.getConvensationId());
		Contact sender = new Contact();
		sender.setId(dto.getSenderId());
		message.setSender(sender);
		message.setConvensation(convensation);
		messageReposity.save(message);
		return message.getId();
	}

}
