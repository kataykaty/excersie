package entry.service;

import java.util.List;

import entry.dto.ContactDto;
import entry.dto.ConvensationDto;
import entry.dto.GroupDto;
import entry.dto.MessageDto;

public interface MessageService {

	List<ContactDto> getListContacts(long userId);

	List<GroupDto> getListGroup(long userId);

	Long createContact(ContactDto dto);

	Long createGroup(GroupDto dto);

	Long createConvensation(ConvensationDto dto);

	Long getConvensation(ConvensationDto dto);

	void deleteMessage(Long messageId);

	void deleteGroup(Long groupId);

	GroupDto addMemberIntoGroup(long userId, long groupId);

	GroupDto removeMemberIntoGroup(long userId, long groupId);

	GroupDto findGroup(long groupId);

	List<MessageDto> getMessageFromConvensation(Long conventionId, int pageIndex, int size);

	Long createMessage(MessageDto dto);

}
