package entry.message;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import entry.controller.MessageController;
import entry.jpaObject.AbstractEntity;
import entry.repository.ContactReposity;
import entry.service.MessageService;

@SpringBootApplication
@ComponentScan(basePackageClasses = { MessageService.class, MessageController.class })
@EnableJpaRepositories(basePackageClasses = ContactReposity.class)
@EntityScan(basePackageClasses = AbstractEntity.class)
public class Application {

	public static void main(String arg[]) {
		SpringApplication.run(Application.class);
	}
}
