package entry.message;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.util.CollectionUtils;

import entry.jpaObject.AbstractEntity;
import entry.jpaObject.Contact;
import entry.jpaObject.ContactGroup;
import entry.repository.ContactGroupReposity;
import entry.repository.ContactReposity;

@SpringBootApplication
@EnableJpaRepositories(basePackageClasses=ContactReposity.class)
@EntityScan(basePackageClasses=AbstractEntity.class)
public class Application {
	
	public static void main(String arg[]){
		SpringApplication.run(Application.class);
	}
	
	@Bean
	public CommandLineRunner demo(ContactReposity reposity, ContactGroupReposity groupReposity){
		return (arg) -> {
			
			List<Contact> contacts = addContacts(reposity);			
			addGroup(groupReposity, contacts);
			Iterable<ContactGroup> groups = groupReposity.findAll();
			for(ContactGroup group : groups){
				List<Contact> listContact = group.getListContacts();
				for(Contact contact : listContact){
					System.out.println(contact.getDisplayName());
				}
			}
		};
	}

	private void addGroup(ContactGroupReposity groupReposity, List<Contact> contacts) {
		ContactGroup group = new ContactGroup();
		group.setGroupName("group nhieu chuyen");
		List<Contact> listContacts = new ArrayList<>();
		listContacts.add(contacts.get(0));
		listContacts.add(contacts.get(1));

		group.setListContacts(listContacts);
		groupReposity.save(group);
	}

	private List<Contact> addContacts(ContactReposity reposity) {
		List<Contact> contacts  = new ArrayList<>();
		Contact contact = new Contact();
		contact.setDisplayName("user 1");
		contact.setMailContact("hello1@gmail.com");
		contacts.add(contact);
		
		contact = new Contact();
		contact.setDisplayName("user 2");
		contact.setMailContact("hello2@gmail.com");
		contacts.add(contact);
		
		contact = new Contact();
		contact.setDisplayName("user 3");
		contact.setMailContact("hello@3gmail.com");
		contacts.add(contact);
		
		contact = new Contact();
		contact.setDisplayName("user 4");
		contact.setMailContact("hello4@gmail.com");
		contacts.add(contact);
		
		contact = new Contact();
		contact.setDisplayName("user 5");
		contact.setMailContact("hello5@gmail.com");
		contacts.add(contact);
		reposity.save(contacts);
		return contacts;
	}
}
