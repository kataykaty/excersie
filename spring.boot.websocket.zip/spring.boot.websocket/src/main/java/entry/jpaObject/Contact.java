package entry.jpaObject;

import java.util.List;

import javax.persistence.ConstraintMode;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Contact extends AbstractEntity {

	private String displayName;
	private String mailContact;
	private String system;
	private String description;

	@OneToMany()
	@JoinColumn(foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
	private List<GroupAndContact> groupAndContact;

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getMailContact() {
		return mailContact;
	}

	public void setMailContact(String mailContact) {
		this.mailContact = mailContact;
	}

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<GroupAndContact> getGroupAndContact() {
		return groupAndContact;
	}

	public void setGroupAndContact(List<GroupAndContact> groupAndContact) {
		this.groupAndContact = groupAndContact;
	}

}
