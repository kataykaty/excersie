package entry.jpaObject;

import java.util.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class AbstractEntity {

	protected byte valid;
	protected Date modifyDate;
	protected Date createdDate;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected long id;

	public byte getValid() {
		return valid;
	}

	public void setValid(byte valid) {
		this.valid = valid;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

}
