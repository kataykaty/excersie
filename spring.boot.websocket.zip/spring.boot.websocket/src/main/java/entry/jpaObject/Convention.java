package entry.jpaObject;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Convention extends AbstractEntity{
	
	@ManyToOne
	private ContactGroup group;
	@ManyToOne
	private Contact OwnerUser;
	@ManyToOne
	private Contact OwnerUser2;
	
	private int typeConvention;

	public ContactGroup getGroup() {
		return group;
	}

	public void setGroup(ContactGroup group) {
		this.group = group;
	}
	public Contact getOwnerUser() {
		return OwnerUser;
	}
	public void setOwnerUser(Contact ownerUser) {
		OwnerUser = ownerUser;
	}
	public Contact getOwnerUser2() {
		return OwnerUser2;
	}
	public void setOwnerUser2(Contact ownerUser2) {
		OwnerUser2 = ownerUser2;
	}
	public int getTypeConvention() {
		return typeConvention;
	}
	public void setTypeConvention(int typeConvention) {
		this.typeConvention = typeConvention;
	}
}
