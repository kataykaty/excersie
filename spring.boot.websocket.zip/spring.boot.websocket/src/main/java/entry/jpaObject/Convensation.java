package entry.jpaObject;

import javax.persistence.ConstraintMode;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Convensation extends AbstractEntity {

	@ManyToOne
	@JoinColumn(foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
	private ContactGroup group;

	@ManyToOne
	@JoinColumn(foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
	private Contact ownerUser;

	@ManyToOne
	private Contact ownerUser2;

	private int typeConvention;

	public ContactGroup getGroup() {
		return group;
	}

	public void setGroup(ContactGroup group) {
		this.group = group;
	}

	public Contact getOwnerUser() {
		return ownerUser;
	}

	public void setOwnerUser(Contact ownerUser) {
		this.ownerUser = ownerUser;
	}

	public Contact getOwnerUser2() {
		return ownerUser2;
	}

	public void setOwnerUser2(Contact ownerUser2) {
		this.ownerUser2 = ownerUser2;
	}

	public int getTypeConvention() {
		return typeConvention;
	}

	public void setTypeConvention(int typeConvention) {
		this.typeConvention = typeConvention;
	}
}
