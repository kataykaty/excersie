package entry.jpaObject;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class GroupAndContact extends AbstractEntity {

	@ManyToOne
	private ContactGroup group;

	@ManyToOne
	private Contact contact;

	public ContactGroup getGroup() {
		return group;
	}

	public void setGroup(ContactGroup group) {
		this.group = group;
	}

	public Contact getContact() {
		return contact;
	}

	public void setContact(Contact contact) {
		this.contact = contact;
	}

}
