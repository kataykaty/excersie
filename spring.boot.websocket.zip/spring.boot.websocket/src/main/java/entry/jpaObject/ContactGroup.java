package entry.jpaObject;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
public class ContactGroup extends AbstractEntity {

	private String groupName;

	@OneToMany(mappedBy = "group")
	private List<GroupAndContact> groupAndContact;

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public List<GroupAndContact> getGroupAndContact() {
		return groupAndContact;
	}

	public void setGroupAndContact(List<GroupAndContact> groupAndContact) {
		this.groupAndContact = groupAndContact;
	}

}
