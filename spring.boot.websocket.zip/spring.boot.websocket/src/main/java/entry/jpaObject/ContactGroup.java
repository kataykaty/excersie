package entry.jpaObject;

import java.util.List;

import javax.persistence.ConstraintMode;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class ContactGroup extends AbstractEntity {

	private String groupName;

	@OneToMany()
	@JoinColumn(foreignKey = @ForeignKey(value = ConstraintMode.NO_CONSTRAINT))
	private List<GroupAndContact> groupAndContact;

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public List<GroupAndContact> getGroupAndContact() {
		return groupAndContact;
	}

	public void setGroupAndContact(List<GroupAndContact> groupAndContact) {
		this.groupAndContact = groupAndContact;
	}

}
