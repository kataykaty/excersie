package entry.jpaObject;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;

@Entity
public class ContactGroup extends AbstractEntity {
	private String groupName;
	
	@OneToMany
	private List<Contact> listContacts;
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public List<Contact> getListContacts() {
		return listContacts;
	}
	public void setListContacts(List<Contact> listContacts) {
		this.listContacts = listContacts;
	}
	
}
