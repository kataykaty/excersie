package entry.jpaObject;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Message extends AbstractEntity {

	@ManyToOne
	private Contact sender;

	@ManyToOne
	private Convensation convensation;

	private String messageText;

	public Contact getSender() {
		return sender;
	}

	public void setSender(Contact sender) {
		this.sender = sender;
	}

	public Convensation getConvensation() {
		return convensation;
	}

	public void setConvensation(Convensation convensation) {
		this.convensation = convensation;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
}
