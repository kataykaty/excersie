package entry.jpaObject;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

@Entity
public class Message extends AbstractEntity {
	
	@ManyToOne
	private Contact sender;
	@ManyToOne
	private Convention convention;
	
	private String messageText;
	
	public Contact getSender() {
		return sender;
	}
	public void setSender(Contact sender) {
		this.sender = sender; 
	}
	public Convention getConvention() {
		return convention;
	}
	public void setConvention(Convention convention) {
		this.convention = convention;
	}
	public String getMessageText() {
		return messageText;
	}
	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
}
