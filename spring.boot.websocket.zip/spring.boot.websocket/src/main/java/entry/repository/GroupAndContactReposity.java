package entry.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import entry.jpaObject.Contact;
import entry.jpaObject.ContactGroup;
import entry.jpaObject.GroupAndContact;

public interface GroupAndContactReposity extends CrudRepository<GroupAndContact, Long> {

	@Query("select DISTINCT g from GroupAndContact gc inner join gc.group g where gc.contact.id=:userId")
	List<ContactGroup> findGroupByContact(@Param("userId") long userId);

	@Query("select DISTINCT c from GroupAndContact gc inner join gc.contact c where gc.group.id=:groupId")
	List<Contact> findContactByGroup(@Param("groupId") long groupId);

	@Query("select gc from GroupAndContact gc where gc.group.id=:groupId and gc.contact.id=:userId ")
	List<GroupAndContact> findByGroupAndContact(@Param("groupId") long groupId, @Param("userId") long userId);
}
