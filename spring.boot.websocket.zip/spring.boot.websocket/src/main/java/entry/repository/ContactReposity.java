package entry.repository;

import org.springframework.data.repository.CrudRepository;

import entry.jpaObject.Contact;

public interface ContactReposity extends CrudRepository<Contact, Long>{
}
