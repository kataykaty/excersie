package entry.repository;

import org.springframework.data.repository.CrudRepository;

import entry.jpaObject.Contact;
import entry.jpaObject.Convention;

public interface ConventionReposity extends CrudRepository<Convention, Long>{
}
