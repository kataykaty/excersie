package entry.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import entry.jpaObject.Message;

public interface MessageReposity extends CrudRepository<Message, Long> {
	// lay message theo ownerId, owner2 id;
	// TODO them phan paging, order by.
	@Query("select m from Message m JOIN m.convensation as c "
			+ "where (c.ownerUser.id =:ownerId and c.ownerUser2.id = :owner2Id)"
			+ " or (c.ownerUser2.id =:ownerId and c.ownerUser.id = :owner2Id ) " + " order by m.id desc ")

	Page<Message> getMessageFromUsers(@Param("ownerId") Long ownerId, @Param("ownerId") Long owner2Id,
			@Param("pageable") Pageable pageable);

	// lay message theo group id;
	// TODO them phan paging, order by.
	@Query("select m from Message m  " + "where m.convensation.group.id = :groupId" + " order by m.id desc ")
	Page<Message> getMessageFromGroup(@Param("groupId") Long groupId, Pageable pageable);

	// lay message theo group id;
	// TODO them phan paging, order by.
	@Query("select m from Message m join m.sender se where m.convensation.id = :conventionId " + "order by m.id desc ")
	Page<Message> getMessageFromConvention(@Param("conventionId") Long conventionId, Pageable pageable);

}
