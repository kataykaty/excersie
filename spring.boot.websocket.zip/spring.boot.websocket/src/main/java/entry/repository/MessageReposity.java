package entry.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import entry.jpaObject.Message;

public interface MessageReposity extends CrudRepository<Message, Long> {
	// lay message theo ownerId, owner2 id;
	// TODO them phan paging, order by.
	@Query("select m from Message m JOIN m.convensation as c "
			+ "where (c.ownerUser.id =:ownerId and c.ownerUser2.id = :owner2Id)"
			+ " or  (c.ownerUser2.id =:ownerId and c.ownerUser.id = :owner2Id )")

	List<Message> getMessageFromUsers(Long ownerId, Long owner2Id);

	// lay message theo group id;
	// TODO them phan paging, order by.
	@Query("select m from Message m  " + "where m.convensation.group.id = :groupId ")
	List<Message> getMessageFromGroup(Long groupId);

	// lay message theo group id;
	// TODO them phan paging, order by.
	@Query("select m from Message m join m.sender se where m.convensation.id = :conventionId ")
	List<Message> getMessageFromConvention(Long conventionId);

}
