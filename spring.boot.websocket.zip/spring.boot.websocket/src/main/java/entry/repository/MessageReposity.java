package entry.repository;

import org.springframework.data.repository.CrudRepository;

import entry.jpaObject.Contact;
import entry.jpaObject.Convention;
import entry.jpaObject.Message;

public interface MessageReposity extends CrudRepository<Message, Long>{
}
