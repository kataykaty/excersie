package entry.repository;

import org.springframework.data.repository.CrudRepository;

import entry.jpaObject.Contact;
import entry.jpaObject.ContactGroup;

public interface ContactGroupReposity extends CrudRepository<ContactGroup, Long>{
}
