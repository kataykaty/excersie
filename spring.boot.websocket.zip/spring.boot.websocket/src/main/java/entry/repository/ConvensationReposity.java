package entry.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import entry.jpaObject.Convensation;

public interface ConvensationReposity extends CrudRepository<Convensation, Long> {

	@Query("select c from Convensation c where c.group.id =:groupId ")
	Convensation findByGroupId(Long groupId);

	@Query("select c from Convensation c where (c.ownerUser.id =:ownerId and c.ownerUser2.id = :owner2Id)"
			+ " or  (c.ownerUser2.id =:ownerId and c.ownerUser.id = :owner2Id )")
	Convensation findByContacts(Long ownerId, Long owner2Id);
}
