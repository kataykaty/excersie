package entry.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import entry.dto.ContactDto;
import entry.dto.ConvensationDto;
import entry.dto.GroupDto;
import entry.dto.MessageDto;
import entry.service.MessageService;

@RestController("/messageApi/*")
public class MessageController {

	@Autowired
	MessageService messageService;

	/**
	 * function list contact return list contact of user
	 */
	@RequestMapping("contacts/{userId}")
	public List<ContactDto> getListContact(long userId) {
		List<ContactDto> contacts = messageService.getListContacts(userId);
		return contacts;
	}

	/**
	 * function list contact return list contact of user
	 */
	@RequestMapping("group/{userId}")
	public List<GroupDto> getListGroup(long userId) {
		List<GroupDto> groups = messageService.getListGroup(userId);
		return groups;
	}

	@RequestMapping("groupAddMember/{groupId}/{userId}")
	public GroupDto addMemberIntoGroup(long groupId, long userId) {
		GroupDto group = messageService.addMemberIntoGroup(userId, groupId);
		return group;
	}

	@RequestMapping("groupRemoveMember/{groupId}/{userId}")
	public GroupDto removeMemberIntoGroup(long groupId, long userId) {
		GroupDto group = messageService.removeMemberIntoGroup(userId, groupId);
		return group;
	}

	@RequestMapping("groupMember/{groupId}")
	public GroupDto findGroup(long groupId, long userId) {
		GroupDto group = messageService.findGroup(groupId);
		return group;
	}

	@RequestMapping(value = "createContact", method = RequestMethod.POST)
	public Long createContact(@RequestBody ContactDto dto) {
		Long id = messageService.createContact(dto);
		return id;
	}

	@RequestMapping(value = "createGroup", method = RequestMethod.POST)
	public Long createGroup(@RequestBody GroupDto dto) {
		Long id = messageService.createGroup(dto);
		return id;
	}

	@RequestMapping(value = "createMessage", method = RequestMethod.POST)
	public Long createMessage(@RequestBody MessageDto dto) {
		Long id = messageService.createMessage(dto);
		return id;
	}

	@RequestMapping(value = "createConvensation", method = RequestMethod.POST)
	public Long createConvensation(@RequestBody ConvensationDto dto) {
		Long id = messageService.createConvensation(dto);
		return id;
	}

	@RequestMapping(value = "convensation")
	public Long getConvensation(@RequestBody ConvensationDto dto) {
		Long id = messageService.getConvensation(dto);
		return id;
	}

	@RequestMapping(value = "deleteMessage")
	public void deleteMessage(Long messageId) {
		messageService.deleteMessage(messageId);
	}

	@RequestMapping(value = "deleteGroup")
	public void deleteGroup(Long groupId) {
		messageService.deleteGroup(groupId);
	}

	@RequestMapping(value = "conventionMessage/{convensationId}/{pageIndex}/{size}")
	public List<MessageDto> getMessageFromConvention(Long convensationId, int pageIndex, int size) {
		List<MessageDto> messages = messageService.getMessageFromConvensation(convensationId, pageIndex, size);
		return messages;
	}

}
